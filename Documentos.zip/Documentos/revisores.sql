
CREATE TABLE `revisores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  `apellido` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO `revisores` (`nombre`, `apellido`) VALUES ('Nombre', 'Revisor1');
INSERT INTO `revisores` (`nombre`, `apellido`) VALUES ('Nombre', 'Revisor2');
INSERT INTO `revisores` (`nombre`, `apellido`) VALUES ('Nombre', 'Revisor3');
INSERT INTO `revisores` (`nombre`, `apellido`) VALUES ('Nombre', 'Revisor4');
INSERT INTO `revisores` (`nombre`, `apellido`) VALUES ('Nombre', 'Revisor5');
INSERT INTO `revisores` (`nombre`, `apellido`) VALUES ('Nombre', 'Revisor6');
INSERT INTO `revisores` (`nombre`, `apellido`) VALUES ('Nombre', 'Revisor7');
INSERT INTO `revisores` (`nombre`, `apellido`) VALUES ('Nombre', 'Revisor8');