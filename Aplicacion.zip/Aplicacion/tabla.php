<?php
include("conexion.php");
include("funciones.php");
$consulta2=$bd->query("SELECT * FROM datos.usuarios_activos");
$cant2=$consulta2->num_rows;

$consulta3=$bd->query("SELECT * FROM datos.usuarios_inactivos");
$cant3=$consulta3->num_rows;

$consulta4=$bd->query("SELECT * FROM datos.usuarios_espera");
$cant4=$consulta4->num_rows;

?>
<!DOCTYPE html>
<html lang='es'>
    <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Datos</title>
 
	<!-- CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>         
                 <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.1/themes/base/jquery-ui.css" />
        <script src="http://code.jquery.com/ui/1.10.1/jquery-ui.js"></script>
           <link href="css/estilos.css" rel="stylesheet" type="text/css"/>
 
           <?php 
           
           include("header.php");
           ?>
           <a href="inicio2.php" class="badge badge-light">Volver</a>    
               <?php
           if($cant2>0){?>
           <br>
           <h3>Usuarios activos</h3>
            <table class="table table-bordered" id='tabla'>
                <thead class='thead-dark'>
                    <tr>
                        <th scope='col'>EMAIL</th>
                        <th scope='col'>NOMBRE</th>
                        <th scope='col'>APELLIDO</th>      
                        <th scope='col'>REVISOR</th>
                    </tr>
                </thead>
                <tbody>
                    
                <?php while($fila2=$consulta2->fetch_array()){ ?>
                    <tr>
                        <td><?php echo $fila2['email'];?></td>
                        <td><?php echo $fila2['nombre'];?></td>
                        <td><?php echo $fila2['apellido'];?></td>
                        <td><?php echo nombreR($fila2['revisor']);?></td>
                 
                
                <?php } ?>
                    </tr>
                </tbody>
            </table>
           <?php } ?>
           
           <br><br>
           <?php if($cant3>0){?>
           <h3>Usuarios inactivos</h3>
            <table class="table table-bordered" id='tabla'>
                <thead class='thead-dark'>
                    <tr>
                        <th scope='col'>EMAIL</th>
                        <th scope='col'>NOMBRE</th>
                        <th scope='col'>APELLIDO</th>
                        <th scope='col'>REVISOR</th>
                    </tr>
                </thead>
                <tbody>
                    
                <?php while($fila3=$consulta3->fetch_array()){ ?>
                    <tr>
                        <td><?php echo $fila3['email'];?></td>
                        <td><?php echo $fila3['nombre'];?></td>
                        <td><?php echo $fila3['apellido'];?></td>
                        <td><?php echo nombreR($fila3['revisor']);?></td>
                 
                
                <?php } ?>
                    </tr>
                </tbody>
            </table>
           <?php } ?>
           
           <br><br>
           <?php if($cant4>0){?>
           <h3>Usuarios en espera</h3>
            <table class="table table-bordered" id='tabla'>
                <thead class='thead-dark'>
                    <tr>
                        <th scope='col'>EMAIL</th>
                        <th scope='col'>NOMBRE</th>
                        <th scope='col'>APELLIDO</th>
                        <th scope='col'>REVISOR</th>
                    </tr>
                </thead>
                <tbody>
                    
                <?php while($fila4=$consulta4->fetch_array()){ ?>
                    <tr>
                        <td><?php echo $fila4['email'];?></td>
                        <td><?php echo $fila4['nombre'];?></td>
                        <td><?php echo $fila4['apellido'];?></td>
                        <td><?php echo nombreR($fila4['revisor']);?></td>
                 
                
                <?php } ?>
                    </tr>
                </tbody>
            </table>
           <?php } ?>
           
           
           
           
            </center>
