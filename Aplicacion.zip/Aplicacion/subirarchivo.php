<?php        $bd = new mysqli("localhost","root","","");

	
      $fname = $_FILES['txt']['name'];
         $chk_ext = explode(".",$fname);
 
         if(strtolower(end($chk_ext)) == "txt")
         {
             $filename = $_FILES['txt']['tmp_name'];
             $handle = fopen($filename, "r");
             $cont=0;
             while (($data1 = fgetcsv($handle, 1000, ",")) !== FALSE)
             {
                 if($data1[2]==""){
                   $cont=$cont+1;
                 } 
             }
              fclose($handle);
             $filename1 = $_FILES['txt']['tmp_name'];
             $handle1 = fopen($filename1, "r");
             if($cont==0){            
               while (($data = fgetcsv($handle1, 1000, ",")) !== FALSE){
               $d1=$data[4]-1;
               $consultaR=$bd->query("SELECT id FROM datos.revisores limit $d1,1");echo "SELECT id FROM datos.revisores limit $d1,1";
               $filaR=$consultaR->fetch_array();
               $id=$filaR['id'];
                switch ($data[3]) {
                         case '1':
                       $sql=$bd->query("INSERT INTO datos.`usuarios_activos`(`email`, `nombre`, `apellido`, `revisor`) VALUES ('$data[0]','$data[1]','$data[2]', '$id')");
                             break;
                          case '2':
                       $sql=$bd->query("INSERT INTO datos.`usuarios_inactivos`(`email`, `nombre`, `apellido`, `revisor`) VALUES ('$data[0]','$data[1]','$data[2]', '$id')");
                             break;
                          case '3':
                       $sql=$bd->query("INSERT INTO datos.`usuarios_espera`(`email`, `nombre`, `apellido`, `revisor`) VALUES ('$data[0]','$data[1]','$data[2]', '$id')");
                             break;

                     }                                
               }  
   fclose($handle);
   echo "<script>window.location.href='tabla.php'</script>";
             }else{
                 echo "<script>alert('El archivo no tiene el formato correcto')</script>";
                    echo "<script>window.location.href='inicio2.php'</script>";

             }

            
         }
         else
         {
          
             echo "Archivo invalido!";
         }
    
 
?>