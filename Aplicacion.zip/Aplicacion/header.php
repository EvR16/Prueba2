<head>
 <link href="css/estilos.css" rel="stylesheet" type="text/css"/>   
<div class="header">
    <img src="Imagenes/logo.jpg">
</div>  
</head>