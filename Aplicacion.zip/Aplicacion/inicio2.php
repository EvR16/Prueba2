<?php
include("conexion.php");
?>
<!DOCTYPE html>
<html lang='es'>
    <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>GEMA SAS</title>

	<!-- CSS -->
        <link href="css/estilos.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
            <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
            <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
             <script src="js/js_aplicacion.js" type="text/javascript"></script>

</head>

<body>
    
    <?php 
    include("header.php");
    ?>
    
<center>
    <div class="card">
  <div class="card-body">
      <h2>Formulario de carga de informaci&oacute;n</h2>  </div>
</div>
   <form  name='subir_archivo' method='post' enctype='multipart/form-data'> 
    <input  type='file' name='txt' class="btn btn-primary btn-lg btn-block" id='boton2'><br />
 <input type='button' value='Enviar formulario'  id="envio">
  <br />
   
   </form>
</center>

 
    
 
