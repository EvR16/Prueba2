<?php
function nombreR($id){
include("conexion.php");
$consultar=$bd->query("SELECT apellido FROM datos.revisores WHERE id='$id'");
$filaR=$consultar->fetch_array();
return ($filaR['apellido']);
}
?>